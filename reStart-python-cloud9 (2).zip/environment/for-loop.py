print("Count to 10!")7


